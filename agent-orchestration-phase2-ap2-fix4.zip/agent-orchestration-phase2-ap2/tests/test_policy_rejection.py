from pathlib import Path

import pytest

from agent_orchestration.bus.eventbus import EventBus
from agent_orchestration.orchestrator.ap2policy import AP2PolicyManager
from agent_orchestration.orchestrator.graph import OrchestratorGraph
from agent_orchestration.shared.audit import AuditLogger
from agent_orchestration.shared.models import AgentType, RunStage, AP2Policy
from agent_orchestration.wallets.wallets import AgentWallet, MasterWallet


@pytest.mark.asyncio
async def test_policy_rejection(tmp_path: Path):
    audit = AuditLogger(tmp_path / "audit.jsonl")
    bus = EventBus()
    for t in AgentType:
        bus.register_agent(t)
    master = MasterWallet("master", 10.0)
    wallets = {t.value: AgentWallet(t.value, 0.0) for t in AgentType}
    ap2 = AP2PolicyManager()
    ap2.create_default_policies()
    ap2.policies[AgentType.DATA] = AP2Policy.fresh(AgentType.DATA.value, 0.0, 0.0, ["data.x402.org"])
    ap2.policies[AgentType.DATA] = ap2._sign(ap2.policies[AgentType.DATA])
    graph = OrchestratorGraph(bus, audit, ap2, master, wallets)

    state = await graph.run("Analyze SOL market")

    assert state.degraded is True
    assert len(state.authorized_tasks) == 2
    assert state.total_spent == pytest.approx(0.07, abs=1e-6)
